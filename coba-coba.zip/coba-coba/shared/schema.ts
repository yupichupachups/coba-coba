import { z } from "zod";

export const quizAnswerSchema = z.object({
  questionId: z.number(),
  selectedAnswer: z.number(),
  isCorrect: z.boolean(),
});

export const quizResultSchema = z.object({
  score: z.number(),
  totalQuestions: z.number(),
  answers: z.array(quizAnswerSchema),
  timestamp: z.string(),
});

export type QuizAnswer = z.infer<typeof quizAnswerSchema>;
export type QuizResult = z.infer<typeof quizResultSchema>;

export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}
