import { Question } from "@shared/schema";

export const questions: Question[] = [
  {
    id: 1,
    question: "Suku ke-5 dari barisan aritmetika 3, 7, 11, 15, ... adalah ...",
    options: ["17", "19", "21", "23"],
    correctAnswer: 1,
    explanation: "Diketahui a = 3, b = 4. Menggunakan rumus Uₙ = a + (n-1)b, maka U₅ = 3 + (5-1)×4 = 3 + 16 = 19"
  },
  {
    id: 2,
    question: "Jumlah 10 suku pertama dari barisan 2, 4, 6, 8, ... adalah ...",
    options: ["100", "110", "120", "130"],
    correctAnswer: 1,
    explanation: "a = 2, b = 2, n = 10. Sₙ = n/2 × (2a + (n-1)b) = 10/2 × (2×2 + 9×2) = 5 × 22 = 110"
  },
  {
    id: 3,
    question: "Beda dari barisan aritmetika 5, 9, 13, 17, ... adalah ...",
    options: ["2", "3", "4", "5"],
    correctAnswer: 2,
    explanation: "Beda (b) = suku kedua - suku pertama = 9 - 5 = 4"
  },
  {
    id: 4,
    question: "Suku pertama dari barisan aritmetika yang memiliki U₃ = 11 dan b = 3 adalah ...",
    options: ["3", "5", "7", "9"],
    correctAnswer: 1,
    explanation: "U₃ = a + 2b, maka 11 = a + 2×3, sehingga 11 = a + 6, jadi a = 5"
  },
  {
    id: 5,
    question: "Suku ke-20 dari barisan 1, 4, 7, 10, ... adalah ...",
    options: ["55", "58", "61", "64"],
    correctAnswer: 1,
    explanation: "a = 1, b = 3. U₂₀ = 1 + (20-1)×3 = 1 + 57 = 58"
  },
  {
    id: 6,
    question: "Jumlah 15 suku pertama dari barisan -3, 0, 3, 6, ... adalah ...",
    options: ["270", "285", "300", "315"],
    correctAnswer: 1,
    explanation: "a = -3, b = 3, n = 15. S₁₅ = 15/2 × (2×(-3) + 14×3) = 7.5 × 38 = 285"
  },
  {
    id: 7,
    question: "Diketahui barisan aritmetika dengan U₅ = 17 dan U₈ = 26. Suku pertama barisan tersebut adalah ...",
    options: ["3", "5", "7", "9"],
    correctAnswer: 1,
    explanation: "U₈ - U₅ = 3b, maka 26 - 17 = 3b, sehingga b = 3. Dari U₅ = a + 4b, maka 17 = a + 12, jadi a = 5"
  },
  {
    id: 8,
    question: "Suku tengah dari barisan aritmetika 5, 8, 11, ..., 50 adalah ...",
    options: ["25.5", "27.5", "29.5", "31.5"],
    correctAnswer: 1,
    explanation: "Suku terakhir 50 = 5 + (n-1)×3, maka n = 16. Suku tengah = (U₈ + U₉)/2 = (26 + 29)/2 = 27.5"
  },
  {
    id: 9,
    question: "Jumlah bilangan asli antara 1 dan 100 yang habis dibagi 5 adalah ...",
    options: ["950", "1000", "1050", "1100"],
    correctAnswer: 2,
    explanation: "Barisan: 5, 10, 15, ..., 95. a = 5, b = 5, n = 19. S₁₉ = 19/2 × (5 + 95) = 9.5 × 100 = 950. Ditambah 100, jadi 1050"
  },
  {
    id: 10,
    question: "Suku ke-n dari barisan aritmetika dengan U₂ = 7 dan U₅ = 16 adalah ...",
    options: ["3n + 1", "3n + 2", "3n - 2", "2n + 3"],
    correctAnswer: 0,
    explanation: "U₅ - U₂ = 3b, maka 16 - 7 = 3b, sehingga b = 3. Dari U₂ = a + b = 7, maka a = 4. Uₙ = 4 + (n-1)×3 = 3n + 1"
  },
];
