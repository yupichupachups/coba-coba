import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, XCircle, Trophy, RotateCcw } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { questions } from "@/data/questions";

export default function Kuis() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateScore();
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correct++;
      }
    });
    setScore(correct);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
    setScore(0);
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const currentQ = questions[currentQuestion];

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 80) return "Luar biasa! Kamu sangat memahami materi ini! 🎉";
    if (percentage >= 60) return "Bagus! Terus tingkatkan pemahaman kamu! 👍";
    return "Semangat! Yuk pelajari lagi materinya! 💪";
  };

  const getScoreColor = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 80) return "text-green-600 dark:text-green-400";
    if (percentage >= 60) return "text-orange-600 dark:text-orange-400";
    return "text-red-600 dark:text-red-400";
  };

  if (showResults) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        
        <main className="flex-1 pt-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
            <Card className="text-center">
              <CardHeader>
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Trophy className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="text-3xl mb-2">Kuis Selesai!</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="text-6xl font-bold mb-2" data-testid="text-score">
                    <span className={getScoreColor()}>{score}</span>
                    <span className="text-muted-foreground">/{questions.length}</span>
                  </p>
                  <p className="text-xl text-muted-foreground">
                    Skor: {Math.round((score / questions.length) * 100)}%
                  </p>
                </div>

                <p className="text-lg font-medium" data-testid="text-score-message">
                  {getScoreMessage()}
                </p>

                <div className="space-y-3">
                  {questions.map((question, index) => (
                    <Card key={question.id} className="text-left">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          {selectedAnswers[index] === question.correctAnswer ? (
                            <CheckCircle2 className="h-5 w-5 text-green-600 mt-1 flex-shrink-0" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-600 mt-1 flex-shrink-0" />
                          )}
                          <div className="flex-1">
                            <p className="font-medium mb-2">{question.question}</p>
                            <p className="text-sm text-muted-foreground">
                              Jawaban kamu: <span className={selectedAnswers[index] === question.correctAnswer ? "text-green-600" : "text-red-600"}>
                                {question.options[selectedAnswers[index]] || "Tidak dijawab"}
                              </span>
                            </p>
                            <p className="text-sm text-green-600 dark:text-green-400">
                              Jawaban benar: {question.options[question.correctAnswer]}
                            </p>
                            {question.explanation && (
                              <p className="text-sm text-muted-foreground mt-2 bg-muted/50 p-2 rounded">
                                💡 {question.explanation}
                              </p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <Button onClick={resetQuiz} size="lg" className="gap-2" data-testid="button-retry">
                  <RotateCcw className="h-5 w-5" />
                  Coba Lagi
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>

        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 pt-16">
        <div className="bg-primary text-primary-foreground py-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4 text-center" data-testid="text-kuis-title">
              Kuis Interaktif
            </h1>
            <p className="text-lg text-primary-foreground/90 text-center">
              Uji pemahamanmu tentang barisan dan deret aritmetika
            </p>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-muted-foreground">
                Pertanyaan {currentQuestion + 1} dari {questions.length}
              </span>
              <span className="text-sm font-medium text-muted-foreground">
                {Math.round(progress)}%
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl" data-testid={`text-question-${currentQuestion}`}>
                {currentQ.question}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {currentQ.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  className={`w-full text-left p-4 rounded-md border-2 transition-all hover-elevate ${
                    selectedAnswers[currentQuestion] === index
                      ? "border-primary bg-primary/10"
                      : "border-border bg-card"
                  }`}
                  data-testid={`button-answer-${index}`}
                >
                  <span className="font-medium">{String.fromCharCode(65 + index)}.</span> {option}
                </button>
              ))}

              <div className="flex gap-3 pt-6">
                <Button
                  onClick={handlePrevious}
                  disabled={currentQuestion === 0}
                  variant="outline"
                  className="flex-1"
                  data-testid="button-previous"
                >
                  Sebelumnya
                </Button>
                <Button
                  onClick={handleNext}
                  disabled={selectedAnswers[currentQuestion] === undefined}
                  className="flex-1"
                  data-testid="button-next"
                >
                  {currentQuestion === questions.length - 1 ? "Selesai" : "Selanjutnya"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
