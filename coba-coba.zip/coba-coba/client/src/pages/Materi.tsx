import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb, Calculator, BookOpen } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function Materi() {
  const examples = [
    {
      question: "Tentukan suku ke-10 dari barisan aritmetika 3, 7, 11, 15, ...",
      steps: [
        "Diketahui: a = 3 (suku pertama), b = 4 (beda), n = 10",
        "Rumus: Uₙ = a + (n - 1)b",
        "U₁₀ = 3 + (10 - 1) × 4",
        "U₁₀ = 3 + 9 × 4",
        "U₁₀ = 3 + 36",
        "U₁₀ = 39",
      ],
      answer: "Jadi, suku ke-10 adalah 39",
    },
    {
      question: "Hitunglah jumlah 15 suku pertama dari barisan 2, 5, 8, 11, ...",
      steps: [
        "Diketahui: a = 2, b = 3, n = 15",
        "Rumus: Sₙ = n/2 × (2a + (n - 1)b)",
        "S₁₅ = 15/2 × (2(2) + (15 - 1) × 3)",
        "S₁₅ = 7.5 × (4 + 14 × 3)",
        "S₁₅ = 7.5 × (4 + 42)",
        "S₁₅ = 7.5 × 46",
        "S₁₅ = 345",
      ],
      answer: "Jadi, jumlah 15 suku pertama adalah 345",
    },
    {
      question: "Diketahui barisan aritmetika dengan U₃ = 11 dan U₇ = 23. Tentukan suku pertama dan beda!",
      steps: [
        "Diketahui: U₃ = 11 dan U₇ = 23",
        "U₃ = a + 2b = 11 ... (1)",
        "U₇ = a + 6b = 23 ... (2)",
        "Kurangkan persamaan (2) dengan (1):",
        "(a + 6b) - (a + 2b) = 23 - 11",
        "4b = 12",
        "b = 3",
        "Substitusi b = 3 ke persamaan (1):",
        "a + 2(3) = 11",
        "a + 6 = 11",
        "a = 5",
      ],
      answer: "Jadi, suku pertama (a) = 5 dan beda (b) = 3",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 pt-16">
        <div className="bg-primary text-primary-foreground py-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4" data-testid="text-materi-title">
              Materi Pembelajaran
            </h1>
            <p className="text-lg text-primary-foreground/90">
              Pelajari konsep barisan dan deret aritmetika secara mendalam
            </p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center">
                  <Lightbulb className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-2xl">Pengertian Barisan Aritmetika</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground leading-relaxed">
                <strong className="text-foreground">Barisan aritmetika</strong> adalah suatu barisan bilangan yang memiliki selisih (beda) yang tetap antara dua suku yang berurutan. Selisih ini disebut dengan <strong className="text-foreground">beda (b)</strong>.
              </p>
              <div className="bg-accent/50 p-6 rounded-md border-l-4 border-primary">
                <p className="text-sm text-muted-foreground mb-3">Bentuk Umum:</p>
                <p className="font-mono text-lg text-center mb-4">
                  a, a + b, a + 2b, a + 3b, ...
                </p>
                <p className="text-sm text-muted-foreground">
                  dengan a = suku pertama, b = beda
                </p>
              </div>
              <div className="bg-muted/50 p-4 rounded-md">
                <p className="text-sm font-medium mb-2">Rumus Suku ke-n:</p>
                <p className="font-mono text-lg text-center">
                  U<sub>n</sub> = a + (n - 1)b
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-2xl">Pengertian Deret Aritmetika</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground leading-relaxed">
                <strong className="text-foreground">Deret aritmetika</strong> adalah jumlah dari suku-suku barisan aritmetika. Jika barisan aritmetika dijumlahkan, maka akan membentuk deret aritmetika.
              </p>
              <div className="bg-accent/50 p-6 rounded-md border-l-4 border-primary">
                <p className="text-sm text-muted-foreground mb-3">Bentuk Umum:</p>
                <p className="font-mono text-lg text-center mb-4">
                  a + (a + b) + (a + 2b) + ... + U<sub>n</sub>
                </p>
              </div>
              <div className="bg-muted/50 p-4 rounded-md">
                <p className="text-sm font-medium mb-2">Rumus Jumlah n Suku Pertama:</p>
                <p className="font-mono text-lg text-center mb-3">
                  S<sub>n</sub> = n/2 × (a + U<sub>n</sub>)
                </p>
                <p className="text-center text-muted-foreground text-sm">atau</p>
                <p className="font-mono text-lg text-center mt-3">
                  S<sub>n</sub> = n/2 × (2a + (n - 1)b)
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary/10 rounded-md flex items-center justify-center">
                <Calculator className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-2xl font-bold">Contoh Soal dan Pembahasan</h2>
            </div>

            <div className="space-y-6">
              {examples.map((example, index) => (
                <Card key={index} data-testid={`card-example-${index}`}>
                  <CardHeader>
                    <CardTitle className="text-lg">
                      Contoh {index + 1}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-accent/30 p-4 rounded-md">
                      <p className="font-medium text-foreground">{example.question}</p>
                    </div>
                    
                    <div>
                      <p className="font-semibold mb-3 text-primary">Pembahasan:</p>
                      <ol className="space-y-2">
                        {example.steps.map((step, stepIndex) => (
                          <li key={stepIndex} className="text-muted-foreground ml-4">
                            {stepIndex + 1}. {step}
                          </li>
                        ))}
                      </ol>
                    </div>

                    <div className="bg-primary/10 p-4 rounded-md border-l-4 border-primary">
                      <p className="font-semibold text-primary">{example.answer}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
