export default function Footer() {
  return (
    <footer className="bg-card border-t border-border py-8 mt-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            © 2025 Belajar Barisan dan Deret Aritmetika. Platform edukasi untuk siswa SMA.
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Dibuat dengan semangat untuk membantu pembelajaran matematika
          </p>
        </div>
      </div>
    </footer>
  );
}
