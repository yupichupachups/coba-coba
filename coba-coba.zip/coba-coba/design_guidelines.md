# Design Guidelines: Belajar Barisan dan Deret Aritmetika

## Design Approach
**Educational Engagement Pattern** - Drawing inspiration from modern educational platforms like Khan Academy and Duolingo, combined with the clean, approachable aesthetics of contemporary learning apps. The design prioritizes clarity, visual hierarchy, and interactive elements that maintain student engagement while ensuring mathematical content remains readable and comprehensible.

## Core Design Elements

### A. Typography
**Primary Font Family**: Poppins (via Google Fonts CDN)
- Headings: Poppins 700 (Bold) - sizes: 2.5rem (h1), 2rem (h2), 1.5rem (h3)
- Subheadings: Poppins 600 (SemiBold) - 1.25rem
- Body text: Poppins 400 (Regular) - 1rem (16px)
- Mathematical formulas: Poppins 500 (Medium) - 1.125rem for emphasis
- Buttons/CTAs: Poppins 600 (SemiBold) - 1rem
- Quiz questions: Poppins 500 (Medium) - 1.125rem
- Small text/captions: Poppins 400 (Regular) - 0.875rem

**Line Height**: 1.6 for body text, 1.3 for headings

### B. Color System
**Primary Colors**:
- Main Blue: #4FC3F7 (primary actions, headers, active states)
- Accent Blue: #0288D1 (hover states, links)
- Success Green: #4CAF50 (correct answers, positive feedback)
- Error Red: #F44336 (incorrect answers, alerts)
- Warning Orange: #FF9800 (neutral feedback, tips)

**Neutral Colors**:
- Pure White: #FFFFFF (backgrounds, cards)
- Light Gray: #F5F5F5 (alternate backgrounds, subtle sections)
- Medium Gray: #E0E0E0 (borders, dividers)
- Text Gray: #424242 (body text)
- Dark Text: #212121 (headings, emphasis)

**Dark Mode Palette** (bonus feature):
- Dark Background: #1A1A1A
- Card Background: #2D2D2D
- Dark Text: #E0E0E0
- Primary Blue remains #4FC3F7 for contrast

### C. Layout System
**Spacing Scale**: Use Tailwind-compatible units: 2, 4, 6, 8, 12, 16, 20, 24
- Component padding: p-6 to p-8
- Section spacing: py-16 to py-20
- Card gaps: gap-6 to gap-8
- Form field spacing: space-y-4

**Container Widths**:
- Max content width: max-w-6xl (1152px)
- Card/component max: max-w-4xl (896px)
- Quiz questions: max-w-3xl (768px)
- Form elements: max-w-md (448px)

**Grid System**:
- Desktop: 3-column grid for feature cards (grid-cols-3)
- Tablet: 2-column grid (md:grid-cols-2)
- Mobile: Single column (grid-cols-1)
- Quiz options: 2-column on desktop, single on mobile

### D. Component Library

**Navigation Bar**:
- Fixed top position with white background, subtle shadow (shadow-md)
- Height: 72px (h-18)
- Logo/title on left (Poppins 700, 1.5rem)
- Navigation links: "Home | Materi | Kuis" centered or right-aligned
- Hamburger menu for mobile (< 768px)
- Active page indicator: bottom border (3px solid #4FC3F7)
- Hover state: text color changes to #4FC3F7

**Hero Section (Home Page)**:
- Full-width background with gradient overlay (linear-gradient from #4FC3F7 to #0288D1)
- Height: 80vh minimum
- Centered content: main heading, subtitle, CTA button
- Optional: decorative mathematical pattern background (geometric shapes, formulas in light opacity)
- CTA Button: large, prominent, white text on transparent dark background with blur effect

**Content Cards**:
- White background with subtle shadow (shadow-lg)
- Rounded corners: border-radius 12px
- Padding: p-8
- Hover effect: slight lift (transform translateY(-4px)), enhanced shadow
- Border: 1px solid #E0E0E0

**Formula Display Boxes**:
- Light blue background (#E3F2FD)
- Monospace-style formatting for mathematical expressions
- Padding: p-6
- Border-left: 4px solid #4FC3F7 (accent indicator)
- Font-size: 1.125rem
- Center-aligned for main formulas

**Quiz Components**:
- Question card: White background, shadow-md, p-8
- Question number indicator: Small badge with primary blue background
- Answer options: Large clickable cards (min-height 60px)
  - Default: white background, border 2px solid #E0E0E0
  - Hover: border color #4FC3F7, slight scale transform
  - Selected: background #E3F2FD, border #4FC3F7
  - Correct (after submit): background #C8E6C9 (light green), border #4CAF50
  - Incorrect (after submit): background #FFCDD2 (light red), border #F44336
- Progress indicator: horizontal bar showing quiz completion
- Score display: Large circular badge with percentage, color-coded (green > 80%, orange 60-80%, red < 60%)

**Buttons**:
- Primary Button: 
  - Background: #4FC3F7
  - Text: white, Poppins 600
  - Padding: px-8 py-3
  - Border-radius: 8px
  - Hover: background #0288D1, slight scale (1.05)
  - Active: scale (0.98)
- Secondary Button:
  - Background: white
  - Border: 2px solid #4FC3F7
  - Text: #4FC3F7
  - Hover: background #E3F2FD
- On hero image: Background with blur backdrop-filter and dark overlay for readability

**Example/Solution Boxes**:
- Bordered section with light gray background (#F5F5F5)
- Step-by-step layout with numbered steps
- Each step: margin-bottom spacing for clarity
- Final answer highlighted in bold with primary color

**Footer**:
- Background: #212121 (dark)
- Text: white, smaller size (0.875rem)
- Centered content
- Links to pages, copyright, simple social icons
- Height: auto, padding py-8

### E. Images
**Hero Section Image**: 
- Use an abstract, modern illustration of mathematical concepts: geometric patterns, abstract numbers, graph visualizations, or stylized educational imagery
- Overlay: gradient from transparent to #4FC3F7 (60% opacity) for text readability
- Position: background-cover, center
- Alternative: Geometric pattern or gradient background if image not available

**Material Page Icons**:
- Use Material Icons or Heroicons for section indicators
- Icons for: lightbulb (concepts), calculator (formulas), pencil (examples)
- Size: 48px, color: #4FC3F7

**No additional images required** - focus on clean, content-first design with icons and mathematical notation

### F. Responsive Breakpoints
- Mobile: < 640px (single column, stacked navigation, larger touch targets)
- Tablet: 640px - 1024px (2-column grids, simplified layouts)
- Desktop: > 1024px (full multi-column layouts, fixed navigation)

### G. Interactive States & Animations
**Transitions**: All interactive elements use transition-all duration-300 ease-in-out
- Button hover: transform scale, color change
- Card hover: shadow enhancement, subtle lift
- Link hover: color change only
- Quiz answer selection: immediate visual feedback with background color

**Loading States**: 
- Simple fade-in animation for page content (0.5s)
- Skeleton loading for quiz questions if needed

**Feedback Animations**:
- Correct answer: brief checkmark animation, green pulse
- Incorrect answer: gentle shake animation, red pulse
- Quiz completion: confetti effect or celebration animation (subtle)

### H. Accessibility
- Color contrast ratio minimum 4.5:1 for text
- Focus states: 2px outline with #4FC3F7 color
- Keyboard navigation fully supported
- Alt text for all icons and images
- ARIA labels for interactive quiz elements
- Touch targets minimum 44x44px for mobile

This design creates an engaging, modern educational experience that balances visual appeal with functional clarity, ensuring students can focus on learning while enjoying an aesthetically pleasing interface.